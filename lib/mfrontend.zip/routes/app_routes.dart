import 'package:GymFitex/screens/trainer/forgot_password_screen.dart';
import 'package:GymFitex/screens/trainer/reset_password_screen.dart';
import 'package:get/get.dart';

import '../screens/splash_screen.dart';
import '../screens/login_screen.dart';
import '../screens/register_screen.dart';

import '../screens/dashboard/member_dashboard.dart';
import '../screens/admin/admin_dashboard.dart';
import '../screens/admin/manage_members/admin_members_screen.dart';
import '../screens/admin/admin_packages_screen.dart';
import '../screens/admin/manage_members/member_form_page.dart';
import '../routes/auth_middleware.dart';
import '../screens/admin/manage_trainers/admin_trainers_screen.dart';
import '../screens/admin/admin_profile/admin_profile_screen.dart';
import '../screens/admin/payments/manage_payments_screen.dart';
import '../screens/admin/admin_slots_screen.dart';
import '../screens/admin/reports/admin_reports_screen.dart';
import '../screens/notification/notifications_screen.dart'; // ← NEW: notifications
import '../screens/admin/admin_check_in_screen.dart';

// nimra
import '../screens/dashboard/member_profile.dart';
import '../screens/dashboard/member_membership.dart';
import '../screens/dashboard/member_trainer.dart';
import '../screens/dashboard/member_payment_screen.dart';
import '../screens/dashboard/member_plans_screen.dart';
import '../screens/dashboard/member_edit_profile.dart';
import '../screens/dashboard/member_change_password.dart';
import '../screens/dashboard/member_diet_screen.dart';
import '../screens/dashboard/member_checkins_screen.dart';

// eman
import '../screens/trainer/trainer_dashboard.dart';
import '../screens/trainer/trainer_members_screen.dart';
import '../screens/trainer/trainer_profile_screen.dart';
import '../screens/trainer/trainer_member_profile_screen.dart';
import '../screens/trainer/trainer_schedule_screen.dart';
import '../screens/trainer/trainer_diet_plans_screen.dart';
import '../screens/trainer/trainer_diet_plan_form.dart';

// routess
class AppRoutes {
  static const String splash = '/';
  static const String onboarding = '/onboarding';
  static const String login = '/login';
  static const String register = '/register';
  static const String dashboard = '/dashboard';
  static const String adminDashboard = '/admin-dashboard';
  static const String adminMembers = '/admin/members';
  static const String adminPackages = '/admin/packages'; // for packges
  static const String addMembers = '/add_members';
  static const String adminTrainers = '/admin/trainers'; // for the trainerss
  static const String adminProfile = '/admin/profile'; // for the profile
  static const String adminPayments = '/admin/payments'; // ← NEW
  static const String adminSlots = '/admin/slots'; // ← NEW
  static const String adminReports = '/admin/reports';
  static const String notifications = '/notifications'; // ← NEW
  static const String adminCheckIn = '/admin/check-in';

  // nimra
  static const String memberProfile = '/member_profile';
  static const String memberMembership = '/member_membership';
  static const String memberTrainer = '/member_trainer';

  //eman
  // ── Trainer routes ───────────────────────────────────────────
  static const String trainerDashboard = '/trainer-dashboard';
  static const String trainerMembers = '/trainer/members';
  static const String trainerProfile = '/trainer/profile';
  static const String trainerMemberProfile = '/trainer/member-profile';
  static const String trainerSchedule = '/trainer/schedule';
  static const String trainerDietPlans = '/trainer/diet-plans';
  static const String trainerDietPlanForm = '/trainer/diet-plan-form';
  static const String forgotPassword = '/forgot-password';
  static const String resetPassword = '/reset-password';

  // pages list
  static final List<GetPage<dynamic>> pages = [
    GetPage(name: splash, page: () => SplashScreen()),
    GetPage(name: login, page: () => LoginScreen()),
    GetPage(name: register, page: () => RegisterScreen()),
    GetPage(name: forgotPassword, page: () => ForgotPasswordScreen()),
    GetPage(name: resetPassword, page: () => ResetPasswordScreen()),
    GetPage(
      name: adminDashboard,
      page: () => AdminDashboard(),
      middlewares: [AuthMiddleware()],
    ),
    GetPage(
      name: adminMembers,
      page: () => AdminMembersScreen(),
      middlewares: [AuthMiddleware()],
    ),
    GetPage(
      name: adminPackages,
      page: () => AdminPackagesScreen(),
      middlewares: [AuthMiddleware()],
    ),
    GetPage(
      name: addMembers,
      page: () => MemberFormPage(),
      middlewares: [AuthMiddleware()],
    ),
    GetPage(
      name: adminTrainers,
      page: () => const AdminTrainersScreen(),
      middlewares: [AuthMiddleware()],
    ),
    GetPage(
      name: adminProfile,
      page: () => const AdminProfileScreen(),
      middlewares: [AuthMiddleware()],
    ),
    GetPage(
      // ← NEW
      name: adminPayments,
      page: () => const ManagePaymentsScreen(),
      middlewares: [AuthMiddleware()],
    ),

    // Add to pages list
    GetPage(
      name: adminSlots,
      page: () => const AdminSlotsScreen(),
      middlewares: [AuthMiddleware()],
    ),
    GetPage(
      name: adminReports,
      page: () => const AdminReportsScreen(),
      middlewares: [AuthMiddleware()],
    ),
    GetPage(
      name: notifications,
      page: () => const NotificationsScreen(),
      middlewares: [AuthMiddleware()],
    ),
    GetPage(
      name: adminCheckIn,
      page: () => const AdminCheckInScreen(),
      middlewares: [AuthMiddleware()],
    ),
    // nimra
    // ── Member ──────────────────────────────────────────────────
    GetPage(
      name: '/member_diet',
      page: () => const MemberDietScreen(),
      middlewares: [AuthMiddleware()],
    ),
    GetPage(
      name: '/member_checkins',
      page: () => const MemberCheckInsScreen(),
      middlewares: [AuthMiddleware()],
    ),
    GetPage(
      name: '/member-edit-profile',
      page: () => MemberEditProfileScreen(),
      middlewares: [AuthMiddleware()],
    ),
    GetPage(
      name: '/member-payment-history',
      page: () => MemberPaymentScreen(),
      middlewares: [AuthMiddleware()],
    ),
    GetPage(
      name: '/member-change-password',
      page: () => MemberChangePasswordScreen(),
      middlewares: [AuthMiddleware()],
    ),
    GetPage(
      name: '/member-plans',
      page: () => MemberPlansScreen(),
      middlewares: [AuthMiddleware()],
    ),
    GetPage(
      name: dashboard,
      page: () => MemberDashboard(),
      middlewares: [AuthMiddleware()],
    ),

    GetPage(
      name: memberMembership,
      page: () => MemberMembershipScreen(),
      middlewares: [AuthMiddleware()],
    ),
    GetPage(
      name: memberTrainer,
      page: () => MemberTrainerScreen(),
      middlewares: [AuthMiddleware()],
    ),
    GetPage(
      name: memberProfile,
      page: () => MemberProfileScreen(),
      middlewares: [AuthMiddleware()],
    ),
    GetPage(
      name: memberMembership,
      page: () => MemberMembershipScreen(),
      middlewares: [AuthMiddleware()],
    ),

    //eman

    // ── Trainer ──────────────────────────────────────────────────
    GetPage(
      name: trainerDashboard,
      page: () => TrainerDashboard(),
      middlewares: [AuthMiddleware()],
    ),
    GetPage(
      name: trainerMembers,
      page: () => TrainerMembersScreen(),
      middlewares: [AuthMiddleware()],
    ),
    GetPage(
      name: trainerProfile,
      page: () => TrainerProfileScreen(),
      middlewares: [AuthMiddleware()],
    ),
    GetPage(
      name: trainerMemberProfile,
      page: () => TrainerMemberProfileScreen(),
      middlewares: [AuthMiddleware()],
    ),
    GetPage(
      name: trainerSchedule,
      page: () => TrainerScheduleScreen(),
      middlewares: [AuthMiddleware()],
    ),
    GetPage(
      name: memberProfile,
      page: () => MemberProfileScreen(),
      middlewares: [AuthMiddleware()],
    ),
    GetPage(
      name: memberMembership,
      page: () => MemberMembershipScreen(),
      middlewares: [AuthMiddleware()],
    ),
    GetPage(
      name: memberTrainer,
      page: () => MemberTrainerScreen(),
      middlewares: [AuthMiddleware()],
    ),
    GetPage(
      name: trainerDietPlans,
      page: () => TrainerDietPlansScreen(),
      middlewares: [AuthMiddleware()],
    ),

    GetPage(
      name: trainerDietPlanForm,
      page: () => TrainerDietPlanForm(),
      middlewares: [AuthMiddleware()],
    ),
  ];
}
