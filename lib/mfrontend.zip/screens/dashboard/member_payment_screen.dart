import 'dart:typed_data';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'dart:convert';
import 'package:http/http.dart' as http;
import 'package:get_storage/get_storage.dart';
import '../../core/utils/theme.dart';
import '../../core/utils/formatters.dart';
import '../../core/widgets/member_layout.dart';
import 'package:image_picker/image_picker.dart';

class MemberPaymentScreen extends StatefulWidget {
  const MemberPaymentScreen({super.key});

  @override
  State<MemberPaymentScreen> createState() => _MemberPaymentScreenState();
}

class _MemberPaymentScreenState extends State<MemberPaymentScreen> {
  final String _selectedMethod = 'online';
  String _selectedmonth = '';
  String _packageAmount = '2000';
  String _packageName = 'Loading...';
  bool _isLoading = false;
  List<dynamic> _payments = [];
  bool _loadingPayments = true;
  final box = GetStorage();

  // Online payment fields
  final _transactionIdController = TextEditingController();
  String? _uploadedImageName;
  XFile? _selectedImage;
  Uint8List? _screenshotBytes;
  final ImagePicker _picker = ImagePicker();

  final List<String> _months = [
    'January 2026',
    'February 2026',
    'March 2026',
    'April 2026',
    'May 2026',
    'June 2026',
    'July 2026',
    'August 2026',
    'September 2026',
    'October 2026',
    'November 2026',
    'December 2026',
  ];

  @override
  void initState() {
    super.initState();
    _selectedmonth = _months[DateTime.now().month - 1];
    _loadPayments();
    _loadMembershipPrice();
  }

  Future<void> _loadMembershipPrice() async {
    try {
      final response = await http.get(
        Uri.parse('http://localhost:3000/api/members/membership'),
        headers: {
          'Content-Type': 'application/json',
          'Authorization': 'Bearer ${_getToken()}',
        },
      );
      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        final price = data['membership']?['price'];
        final pending = data['membership']?['pending_balance'];
        final pName = data['membership']?['package_name'];
        setState(() {
          if (pending != null &&
              double.tryParse(pending.toString()) != null &&
              double.parse(pending.toString()) > 0) {
            _packageAmount = pending.toString();
            _packageName = '$pName (Remaining Balance)';
          } else if (price != null) {
            _packageAmount = price.toString();
            _packageName = pName ?? 'No Plan Assigned';
          } else {
            _packageAmount = '0';
            _packageName = pName ?? 'No Plan Assigned';
          }
        });
      }
    } catch (e) {
      print('Load membership price error: $e');
      setState(() {
        _packageName = 'Error loading plan';
      });
    }
  }

  String _getToken() => box.read('token') ?? '';

  // Load payment history
  Future<void> _loadPayments() async {
    try {
      final response = await http.get(
        Uri.parse('http://localhost:3000/api/payments/my-payments'),
        headers: {
          'Content-Type': 'application/json',
          'Authorization': 'Bearer ${_getToken()}',
        },
      );
      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        setState(() {
          _payments = data['payments'];
          _loadingPayments = false;
        });
      }
    } catch (e) {
      setState(() => _loadingPayments = false);
    }
  }

  // Pick image and store as bytes
  Future<void> _pickImage() async {
    final XFile? image = await _picker.pickImage(
      source: ImageSource.gallery,
      imageQuality: 80,
    );
    if (image != null) {
      final bytes = await image.readAsBytes();
      setState(() {
        _selectedImage = image;
        _screenshotBytes = bytes;
        _uploadedImageName = image.name;
      });
      Get.snackbar(
        'Success',
        'Screenshot selected!',
        backgroundColor: AppTheme.activeLight,
        colorText: AppTheme.active,
        snackPosition: SnackPosition.BOTTOM,
      );
    }
  }

  // Submit payment
  Future<void> _submitPayment() async {
    // Online validation
    if (_selectedMethod == 'online') {
      if (_transactionIdController.text.isEmpty) {
        Get.snackbar(
          'Error',
          'Transaction ID daalo',
          backgroundColor: AppTheme.expiredLight,
          colorText: AppTheme.expired,
          snackPosition: SnackPosition.BOTTOM,
        );
        return;
      }
      if (_screenshotBytes == null) {
        Get.snackbar(
          'Error',
          'Payment screenshot upload karo',
          backgroundColor: AppTheme.expiredLight,
          colorText: AppTheme.expired,
          snackPosition: SnackPosition.BOTTOM,
        );
        return;
      }
    }

    setState(() => _isLoading = true);

    try {
      // Multipart request with bytes
      var request = http.MultipartRequest(
        'POST',
        Uri.parse('http://localhost:3000/api/payments/submit'),
      );

      request.headers['Authorization'] = 'Bearer ${_getToken()}';
      request.fields['amount'] = _packageAmount;
      request.fields['method'] = _selectedMethod;
      request.fields['month'] = _selectedmonth;
      request.fields['transaction_id'] = _transactionIdController.text;

      // Add screenshot bytes
      if (_selectedMethod == 'online' && _screenshotBytes != null) {
        request.files.add(
          http.MultipartFile.fromBytes(
            'screenshot',
            _screenshotBytes!,
            filename: _uploadedImageName ?? 'screenshot.jpg',
          ),
        );
      }

      final streamedResponse = await request.send();
      final response = await http.Response.fromStream(streamedResponse);

      print('Payment Status: ${response.statusCode}');
      print('Payment Body: ${response.body}');

      final data = jsonDecode(response.body);

      if (response.statusCode == 200) {
        Get.snackbar(
          'Success',
          'Payment submit ho gayi! Admin approval ka wait karo.',
          backgroundColor: AppTheme.activeLight,
          colorText: AppTheme.active,
          snackPosition: SnackPosition.BOTTOM,
        );
        _clearFields();
        _loadPayments();
      } else {
        Get.snackbar(
          'Error',
          data['message'] ?? 'Error hua',
          backgroundColor: AppTheme.expiredLight,
          colorText: AppTheme.expired,
          snackPosition: SnackPosition.BOTTOM,
        );
      }
    } catch (e) {
      print('Submit Error: $e');
      Get.snackbar(
        'Error',
        'Error: $e',
        backgroundColor: AppTheme.expiredLight,
        colorText: AppTheme.expired,
        snackPosition: SnackPosition.BOTTOM,
      );
    }

    setState(() => _isLoading = false);
  }

  // Clear all fields
  void _clearFields() {
    _transactionIdController.clear();
    setState(() {
      _uploadedImageName = null;
      _selectedImage = null;
      _screenshotBytes = null;
    });
  }

  Color _statusColor(String status) {
    switch (status) {
      case 'paid':
        return AppTheme.active;
      case 'pending':
        return AppTheme.pending;
      case 'failed':
        return AppTheme.expired;
      default:
        return AppTheme.textSecondary;
    }
  }

  Color _statusLightColor(String status) {
    switch (status) {
      case 'paid':
        return AppTheme.activeLight;
      case 'pending':
        return AppTheme.pendingLight;
      case 'failed':
        return AppTheme.expiredLight;
      default:
        return AppTheme.background;
    }
  }

  @override
  Widget build(BuildContext context) {
    return MemberLayout(
      currentIndex: 2,
      title: 'Member Portal',
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text(
              'Make Payment',
              style: TextStyle(
                fontSize: 22,
                fontWeight: FontWeight.bold,
                color: AppTheme.textPrimary,
              ),
            ),
            const SizedBox(height: 16),

            // Payment form card
            Container(
              width: double.infinity,
              padding: const EdgeInsets.all(20),
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(12),
                boxShadow: [AppTheme.cardShadow],
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  // Package Info Display
                  Container(
                    width: double.infinity,
                    padding: const EdgeInsets.all(12),
                    margin: const EdgeInsets.only(bottom: 16),
                    decoration: BoxDecoration(
                      color: AppTheme.primaryLight,
                      borderRadius: BorderRadius.circular(8),
                      border: Border.all(
                        color: AppTheme.primary.withOpacity(0.2),
                      ),
                    ),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          'Your Package: $_packageName',
                          style: const TextStyle(
                            fontSize: 14,
                            fontWeight: FontWeight.bold,
                            color: AppTheme.primary,
                          ),
                        ),
                        const SizedBox(height: 4),
                        Text(
                          'Amount to Pay: ${formatCurrency(num.tryParse(_packageAmount) ?? 0)}',
                          style: const TextStyle(
                            fontSize: 13,
                            color: AppTheme.textSecondary,
                          ),
                        ),
                      ],
                    ),
                  ),

                  // month dropdown
                  const Text(
                    'Select month',
                    style: TextStyle(
                      fontSize: 13,
                      fontWeight: FontWeight.w500,
                      color: AppTheme.textPrimary,
                    ),
                  ),
                  const SizedBox(height: 8),
                  Container(
                    padding: const EdgeInsets.symmetric(horizontal: 12),
                    decoration: BoxDecoration(
                      color: const Color(0xFFF5F5F5),
                      borderRadius: BorderRadius.circular(12),
                    ),
                    child: DropdownButton<String>(
                      value: _selectedmonth,
                      isExpanded: true,
                      underline: const SizedBox(),
                      items: _months.map((month) {
                        return DropdownMenuItem(
                          value: month,
                          child: Text(month),
                        );
                      }).toList(),
                      onChanged: (val) => setState(() => _selectedmonth = val!),
                    ),
                  ),
                  const SizedBox(height: 16),

                  // Payment method
                  const Text(
                    'Payment Method',
                    style: TextStyle(
                      fontSize: 13,
                      fontWeight: FontWeight.w500,
                      color: AppTheme.textPrimary,
                    ),
                  ),
                  const SizedBox(height: 8),
                  Container(
                    width: double.infinity,
                    padding: const EdgeInsets.all(12),
                    decoration: BoxDecoration(
                      color: AppTheme.primaryLight,
                      borderRadius: BorderRadius.circular(12),
                      border: Border.all(color: AppTheme.primary, width: 1.5),
                    ),
                    child: Row(
                      children: [
                        const Icon(
                          Icons.phone_android,
                          color: AppTheme.primary,
                        ),
                        const SizedBox(width: 8),
                        const Text(
                          'Online',
                          style: TextStyle(
                            color: AppTheme.primary,
                            fontWeight: FontWeight.w500,
                          ),
                        ),
                      ],
                    ),
                  ),

                  const SizedBox(height: 20),

                  // Online payment fields
                  if (_selectedMethod == 'online') ...[
                    const Text(
                      'Upload Payment Screenshot',
                      style: TextStyle(
                        fontSize: 13,
                        fontWeight: FontWeight.w500,
                        color: AppTheme.textPrimary,
                      ),
                    ),
                    const SizedBox(height: 8),

                    // Screenshot picker
                    GestureDetector(
                      onTap: _pickImage,
                      child: Container(
                        width: double.infinity,
                        height: _screenshotBytes != null ? 180 : 110,
                        decoration: BoxDecoration(
                          color: AppTheme.background,
                          borderRadius: BorderRadius.circular(12),
                          border: Border.all(
                            color: _screenshotBytes != null
                                ? AppTheme.active
                                : AppTheme.border,
                          ),
                        ),
                        child: _screenshotBytes != null
                            ? ClipRRect(
                                borderRadius: BorderRadius.circular(12),
                                child: Stack(
                                  fit: StackFit.expand,
                                  children: [
                                    Image.memory(
                                      _screenshotBytes!,
                                      fit: BoxFit.cover,
                                    ),
                                    Positioned(
                                      top: 8,
                                      right: 8,
                                      child: GestureDetector(
                                        onTap: _pickImage,
                                        child: Container(
                                          padding: const EdgeInsets.symmetric(
                                            horizontal: 10,
                                            vertical: 6,
                                          ),
                                          decoration: BoxDecoration(
                                            color: Colors.black54,
                                            borderRadius: BorderRadius.circular(
                                              8,
                                            ),
                                          ),
                                          child: const Text(
                                            'Change',
                                            style: TextStyle(
                                              color: Colors.white,
                                              fontSize: 12,
                                            ),
                                          ),
                                        ),
                                      ),
                                    ),
                                  ],
                                ),
                              )
                            : Column(
                                mainAxisAlignment: MainAxisAlignment.center,
                                children: const [
                                  Icon(
                                    Icons.upload_file,
                                    color: AppTheme.textSecondary,
                                    size: 32,
                                  ),
                                  SizedBox(height: 8),
                                  Text(
                                    'Click to upload screenshot',
                                    style: TextStyle(
                                      color: AppTheme.textSecondary,
                                    ),
                                  ),
                                ],
                              ),
                      ),
                    ),

                    const SizedBox(height: 16),

                    // Transaction ID
                    const Text(
                      'Transaction ID',
                      style: TextStyle(
                        fontSize: 13,
                        fontWeight: FontWeight.w500,
                        color: AppTheme.textPrimary,
                      ),
                    ),
                    const SizedBox(height: 8),
                    _buildField(
                      controller: _transactionIdController,
                      hint: 'Transaction ID enter karo',
                      icon: Icons.tag,
                    ),
                  ],

                  const SizedBox(height: 20),

                  // Submit button
                  SizedBox(
                    width: double.infinity,
                    height: 50,
                    child: ElevatedButton(
                      onPressed: _isLoading ? null : _submitPayment,
                      style: ElevatedButton.styleFrom(
                        backgroundColor: AppTheme.primary,
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(12),
                        ),
                      ),
                      child: _isLoading
                          ? const CircularProgressIndicator(color: Colors.white)
                          : const Text(
                              'Submit Payment',
                              style: TextStyle(
                                fontSize: 16,
                                fontWeight: FontWeight.w600,
                                color: Colors.white,
                              ),
                            ),
                    ),
                  ),
                ],
              ),
            ),

            const SizedBox(height: 16),

            // View history button
            SizedBox(
              width: double.infinity,
              height: 50,
              child: OutlinedButton.icon(
                onPressed: () =>
                    Get.to(() => const MemberPaymentHistoryScreen()),
                style: OutlinedButton.styleFrom(
                  side: const BorderSide(color: AppTheme.primary),
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(12),
                  ),
                ),
                icon: const Icon(Icons.history, color: AppTheme.primary),
                label: const Text(
                  'View Payment History',
                  style: TextStyle(
                    color: AppTheme.primary,
                    fontWeight: FontWeight.w600,
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildField({
    required TextEditingController controller,
    required String hint,
    required IconData icon,
    TextInputType keyboardType = TextInputType.text,
    bool obscureText = false,
  }) {
    return TextField(
      controller: controller,
      keyboardType: keyboardType,
      obscureText: obscureText,
      decoration: InputDecoration(
        hintText: hint,
        hintStyle: const TextStyle(color: AppTheme.textHint),
        prefixIcon: Icon(icon, color: AppTheme.textSecondary, size: 20),
        filled: true,
        fillColor: const Color(0xFFF5F5F5),
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(12),
          borderSide: BorderSide.none,
        ),
        focusedBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(12),
          borderSide: const BorderSide(color: AppTheme.primary, width: 1.5),
        ),
      ),
    );
  }

  @override
  void dispose() {
    _transactionIdController.dispose();
    super.dispose();
  }
}

// Payment History Screen
class MemberPaymentHistoryScreen extends StatefulWidget {
  const MemberPaymentHistoryScreen({super.key});

  @override
  State<MemberPaymentHistoryScreen> createState() =>
      _MemberPaymentHistoryScreenState();
}

class _MemberPaymentHistoryScreenState
    extends State<MemberPaymentHistoryScreen> {
  List<dynamic> _payments = [];
  bool _isLoading = true;
  final box = GetStorage();

  String _getToken() => box.read('token') ?? '';

  @override
  void initState() {
    super.initState();
    _loadPayments();
  }

  Future<void> _loadPayments() async {
    try {
      final response = await http.get(
        Uri.parse('http://localhost:3000/api/payments/my-payments'),
        headers: {
          'Content-Type': 'application/json',
          'Authorization': 'Bearer ${_getToken()}',
        },
      );
      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        setState(() {
          _payments = data['payments'];
          _isLoading = false;
        });
      }
    } catch (e) {
      setState(() => _isLoading = false);
    }
  }

  Color _statusColor(String status) {
    switch (status) {
      case 'paid':
        return AppTheme.active;
      case 'pending':
        return AppTheme.pending;
      case 'failed':
        return AppTheme.expired;
      default:
        return AppTheme.textSecondary;
    }
  }

  Color _statusLightColor(String status) {
    switch (status) {
      case 'paid':
        return AppTheme.activeLight;
      case 'pending':
        return AppTheme.pendingLight;
      case 'failed':
        return AppTheme.expiredLight;
      default:
        return AppTheme.background;
    }
  }

  double get _totalPaid => _payments
      .where((p) => p['status'] == 'paid')
      .fold(0.0, (sum, p) => sum + double.parse(p['amount'].toString()));

  int get _pendingCount =>
      _payments.where((p) => p['status'] == 'pending').length;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppTheme.background,
      appBar: AppBar(
        backgroundColor: AppTheme.primary,
        foregroundColor: Colors.white,
        title: const Text('Payment History'),
        leading: IconButton(
          icon: const Icon(Icons.arrow_back),
          onPressed: () => Get.back(),
        ),
      ),
      body: _isLoading
          ? const Center(
              child: CircularProgressIndicator(color: AppTheme.primary),
            )
          : SingleChildScrollView(
              padding: const EdgeInsets.all(16),
              child: Column(
                children: [
                  // Summary cards
                  Row(
                    children: [
                      Expanded(
                        child: _summaryCard(
                          'Total Paid',
                          formatCurrency(_totalPaid),
                          Icons.check_circle,
                          AppTheme.active,
                          AppTheme.activeLight,
                        ),
                      ),
                      const SizedBox(width: 12),
                      Expanded(
                        child: _summaryCard(
                          'Transactions',
                          '${_payments.length}',
                          Icons.receipt,
                          AppTheme.primary,
                          AppTheme.primaryLight,
                        ),
                      ),
                      const SizedBox(width: 12),
                      Expanded(
                        child: _summaryCard(
                          'Pending',
                          '$_pendingCount',
                          Icons.access_time,
                          AppTheme.pending,
                          AppTheme.pendingLight,
                        ),
                      ),
                    ],
                  ),

                  const SizedBox(height: 16),

                  // Payment list
                  _payments.isEmpty
                      ? Container(
                          padding: const EdgeInsets.all(20),
                          decoration: BoxDecoration(
                            color: Colors.white,
                            borderRadius: BorderRadius.circular(12),
                          ),
                          child: const Center(
                            child: Text(
                              'Koi payment nahi mili',
                              style: TextStyle(color: AppTheme.textSecondary),
                            ),
                          ),
                        )
                      : Column(
                          children: _payments.map((payment) {
                            final status = payment['status'] ?? 'pending';
                            return Container(
                              margin: const EdgeInsets.only(bottom: 10),
                              padding: const EdgeInsets.all(16),
                              decoration: BoxDecoration(
                                color: Colors.white,
                                borderRadius: BorderRadius.circular(12),
                                boxShadow: [AppTheme.cardShadow],
                              ),
                              child: Row(
                                children: [
                                  Container(
                                    padding: const EdgeInsets.all(10),
                                    decoration: BoxDecoration(
                                      color: _statusLightColor(status),
                                      shape: BoxShape.circle,
                                    ),
                                    child: Icon(
                                      status == 'paid'
                                          ? Icons.check_circle
                                          : status == 'pending'
                                          ? Icons.access_time
                                          : Icons.cancel,
                                      color: _statusColor(status),
                                      size: 20,
                                    ),
                                  ),
                                  const SizedBox(width: 12),
                                  Expanded(
                                    child: Column(
                                      crossAxisAlignment:
                                          CrossAxisAlignment.start,
                                      children: [
                                        Text(
                                          payment['month'] ?? 'N/A',
                                          style: const TextStyle(
                                            fontWeight: FontWeight.w600,
                                            fontSize: 15,
                                          ),
                                        ),
                                        Text(
                                          payment['method']?.toUpperCase() ??
                                              '',
                                          style: const TextStyle(
                                            color: AppTheme.textSecondary,
                                            fontSize: 12,
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                  Column(
                                    crossAxisAlignment: CrossAxisAlignment.end,
                                    children: [
                                      Text(
                                        formatCurrency(
                                          num.tryParse(
                                                payment['amount'].toString(),
                                              ) ??
                                              0,
                                        ),
                                        style: const TextStyle(
                                          fontWeight: FontWeight.bold,
                                          fontSize: 15,
                                        ),
                                      ),
                                      Container(
                                        padding: const EdgeInsets.symmetric(
                                          horizontal: 8,
                                          vertical: 2,
                                        ),
                                        decoration: BoxDecoration(
                                          color: _statusLightColor(status),
                                          borderRadius: BorderRadius.circular(
                                            20,
                                          ),
                                        ),
                                        child: Text(
                                          status.toUpperCase(),
                                          style: TextStyle(
                                            color: _statusColor(status),
                                            fontSize: 11,
                                            fontWeight: FontWeight.w600,
                                          ),
                                        ),
                                      ),
                                    ],
                                  ),
                                ],
                              ),
                            );
                          }).toList(),
                        ),
                ],
              ),
            ),
    );
  }

  Widget _summaryCard(
    String label,
    String value,
    IconData icon,
    Color color,
    Color bgColor,
  ) {
    return Container(
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(12),
        boxShadow: [AppTheme.cardShadow],
      ),
      child: Column(
        children: [
          Container(
            padding: const EdgeInsets.all(8),
            decoration: BoxDecoration(color: bgColor, shape: BoxShape.circle),
            child: Icon(icon, color: color, size: 18),
          ),
          const SizedBox(height: 6),
          Text(
            value,
            style: TextStyle(
              fontSize: 16,
              fontWeight: FontWeight.bold,
              color: color,
            ),
          ),
          Text(
            label,
            style: const TextStyle(fontSize: 10, color: AppTheme.textSecondary),
          ),
        ],
      ),
    );
  }
}
